function WeaponTweakData:_set_easy_wish()
	self.ak47_ass_npc.DAMAGE = 2.5
	self.swat_van_turret_module.HEALTH_INIT = 40000
	self.swat_van_turret_module.SHIELD_HEALTH_INIT = 700
	self.swat_van_turret_module.DAMAGE = 3.5
	self.swat_van_turret_module.CLIP_SIZE = 800
	self.ceiling_turret_module.HEALTH_INIT = 20000
	self.ceiling_turret_module.SHIELD_HEALTH_INIT = 350
	self.ceiling_turret_module.DAMAGE = 3.5
	self.ceiling_turret_module.CLIP_SIZE = 800
	self.aa_turret_module.HEALTH_INIT = 40100
	self.aa_turret_module.SHIELD_HEALTH_INIT = 700
	self.aa_turret_module.DAMAGE = 3.5
	self.aa_turret_module.CLIP_SIZE = 800
	self.crate_turret_module.HEALTH_INIT = 20000
	self.crate_turret_module.SHIELD_HEALTH_INIT = 700
	self.crate_turret_module.DAMAGE = 3.5
	self.crate_turret_module.CLIP_SIZE = 800
	self.benelli_npc.usage = "is_shotgun_semi"
	self.benelli_npc.DAMAGE = 3.75
end